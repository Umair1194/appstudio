import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
export function CTASection() {
  return <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-navy-900">
        <div className="absolute inset-0 bg-gradient-to-br from-navy-800 to-navy-900" />
        {/* Decorative gold lines */}
        <div className="absolute top-0 right-0 w-full h-full opacity-10" style={{
        backgroundImage: 'linear-gradient(45deg, #D4AF37 1px, transparent 1px)',
        backgroundSize: '60px 60px'
      }} />
      </div>

      <div className="max-w-4xl mx-auto px-6 lg:px-8 relative z-10 text-center">
        <motion.h2 initial={{
        opacity: 0,
        y: 20
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} transition={{
        duration: 0.6
      }} className="text-4xl md:text-6xl font-serif font-bold text-white mb-6 leading-tight">
          Ready to Elevate Your <br />
          <span className="text-gold-500">Investment Portfolio?</span>
        </motion.h2>

        <motion.p initial={{
        opacity: 0,
        y: 20
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} transition={{
        duration: 0.6,
        delay: 0.1
      }} className="text-xl text-gray-300 mb-10 max-w-2xl mx-auto">
          Join the elite circle of investors shaping the future of the UAE.
          Let's discuss your vision today.
        </motion.p>

        <motion.div initial={{
        opacity: 0,
        y: 20
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} transition={{
        duration: 0.6,
        delay: 0.2
      }} className="flex flex-col sm:flex-row gap-4 justify-center">
          <motion.button whileHover={{
          scale: 1.05
        }} whileTap={{
          scale: 0.95
        }} className="bg-gold-500 text-white px-10 py-4 rounded-full font-medium text-lg shadow-[0_0_20px_rgba(212,175,55,0.3)] hover:shadow-[0_0_30px_rgba(212,175,55,0.5)] transition-shadow">
            Schedule Consultation
          </motion.button>
          <motion.button whileHover={{
          scale: 1.05
        }} whileTap={{
          scale: 0.95
        }} className="bg-transparent border border-white/20 text-white px-10 py-4 rounded-full font-medium text-lg hover:bg-white/10 transition-colors">
            Download Brochure
          </motion.button>
        </motion.div>
      </div>
    </section>;
}