import React from 'react';
import { motion } from 'framer-motion';
import { Building2, Briefcase, Gem, Landmark } from 'lucide-react';
const services = [{
  icon: Building2,
  title: 'Property Development',
  description: 'Creating iconic residential and commercial landmarks that redefine the skyline with sustainable innovation.'
}, {
  icon: Gem,
  title: 'Luxury Real Estate',
  description: 'Curating an exclusive portfolio of high-end properties for the most discerning international investors.'
}, {
  icon: Briefcase,
  title: 'Investment Management',
  description: 'Strategic asset management services designed to maximize returns in the dynamic UAE market.'
}, {
  icon: Landmark,
  title: 'Architectural Design',
  description: 'Award-winning architectural planning that merges modern aesthetics with cultural heritage.'
}];
export function ServicesSection() {
  return <section id="services" className="py-24 bg-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute top-0 left-0 w-full h-full opacity-[0.03] pointer-events-none">
        <div className="absolute right-0 top-0 w-96 h-96 bg-navy-900 rounded-full blur-3xl" />
        <div className="absolute left-0 bottom-0 w-96 h-96 bg-gold-500 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h2 initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6
        }} className="text-4xl md:text-5xl font-serif font-bold text-navy-900 mb-6">
            Our Expertise
          </motion.h2>
          <motion.p initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6,
          delay: 0.1
        }} className="text-lg text-gray-600">
            Delivering excellence across every dimension of real estate and
            development with precision and elegance.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => <motion.div key={index} initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.5,
          delay: index * 0.1
        }} whileHover={{
          y: -8
        }} className="group bg-white p-8 rounded-xl border border-gray-100 shadow-lg hover:shadow-xl hover:shadow-gold-500/10 transition-all duration-300 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-gold-400 to-gold-600 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />

              <div className="w-14 h-14 bg-navy-50 rounded-lg flex items-center justify-center mb-6 group-hover:bg-navy-900 transition-colors duration-300">
                <service.icon className="w-7 h-7 text-navy-900 group-hover:text-gold-500 transition-colors duration-300" />
              </div>

              <h3 className="text-xl font-serif font-bold text-navy-900 mb-3 group-hover:text-gold-600 transition-colors">
                {service.title}
              </h3>

              <p className="text-gray-600 leading-relaxed text-sm">
                {service.description}
              </p>
            </motion.div>)}
        </div>
      </div>
    </section>;
}