import React from 'react';
import { motion } from 'framer-motion';
const stats = [{
  label: 'Projects Completed',
  value: '150+'
}, {
  label: 'Happy Clients',
  value: '2.5k'
}, {
  label: 'Awards Won',
  value: '45'
}, {
  label: 'Years Experience',
  value: '20+'
}];
const partners = ['Emaar', 'Damac', 'Nakheel', 'Aldar', 'Meraas', 'Sobha'];
export function StatsPartners() {
  return <section id="stats" className="py-20 bg-navy-900 text-white relative overflow-hidden">
      {/* Background Texture */}
      <div className="absolute inset-0 opacity-10" style={{
      backgroundImage: 'radial-gradient(#C9A961 1px, transparent 1px)',
      backgroundSize: '30px 30px'
    }}></div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-20 border-b border-white/10 pb-16">
          {stats.map((stat, index) => <motion.div key={index} initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6,
          delay: index * 0.1
        }} className="text-center">
              <h3 className="text-4xl md:text-5xl font-serif font-bold text-gold-500 mb-2">
                {stat.value}
              </h3>
              <p className="text-gray-400 text-sm uppercase tracking-wider font-medium">
                {stat.label}
              </p>
            </motion.div>)}
        </div>

        {/* Partners */}
        <div className="text-center">
          <p className="text-gray-400 text-sm uppercase tracking-widest mb-10">
            Trusted by Industry Leaders
          </p>
          <div className="flex flex-wrap justify-center items-center gap-12 md:gap-20 opacity-60 grayscale hover:grayscale-0 transition-all duration-500">
            {/* Using text placeholders for logos to keep it clean, in production these would be SVGs */}
            {partners.map((partner, index) => <motion.span key={index} initial={{
            opacity: 0
          }} whileInView={{
            opacity: 1
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.5,
            delay: 0.2 + index * 0.1
          }} className="text-2xl font-serif font-bold text-white hover:text-gold-500 transition-colors cursor-default">
                {partner}
              </motion.span>)}
          </div>
        </div>
      </div>
    </section>;
}