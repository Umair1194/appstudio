import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, ChevronDown } from 'lucide-react';
export function HeroSection() {
  return <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background Elements */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-gray-50 to-white" />
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-gold-400/10 to-transparent" />

        {/* Decorative Circles */}
        <motion.div animate={{
        y: [0, -20, 0],
        rotate: [0, 5, 0]
      }} transition={{
        duration: 8,
        repeat: Infinity,
        ease: 'easeInOut'
      }} className="absolute top-1/4 right-[10%] w-96 h-96 rounded-full border border-gold-500/20" />
        <motion.div animate={{
        y: [0, 30, 0],
        rotate: [0, -5, 0]
      }} transition={{
        duration: 10,
        repeat: Infinity,
        ease: 'easeInOut',
        delay: 1
      }} className="absolute bottom-1/4 left-[5%] w-64 h-64 rounded-full border border-navy-900/5" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 w-full">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Text Content */}
          <div className="max-w-2xl">
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6
          }}>
              <span className="inline-block py-1 px-3 rounded-full bg-gold-500/10 text-gold-700 text-xs font-bold tracking-widest uppercase mb-6 border border-gold-500/20">
                Premium Real Estate & Investment
              </span>
            </motion.div>

            <motion.h1 initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6,
            delay: 0.1
          }} className="text-5xl lg:text-7xl font-serif font-bold text-navy-900 leading-[1.1] mb-6">
              Building the <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-gold-500 to-gold-700">
                Future of UAE
              </span>
            </motion.h1>

            <motion.p initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6,
            delay: 0.2
          }} className="text-lg text-gray-600 mb-8 leading-relaxed max-w-lg">
              Experience the pinnacle of luxury and innovation. We craft
              world-class environments that define the skyline of tomorrow.
            </motion.p>

            <motion.div initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6,
            delay: 0.3
          }} className="flex flex-col sm:flex-row gap-4">
              <motion.button whileHover={{
              scale: 1.02
            }} whileTap={{
              scale: 0.98
            }} className="bg-gold-500 text-white px-8 py-4 rounded-md font-medium flex items-center justify-center gap-2 hover:bg-gold-600 transition-colors shadow-lg shadow-gold-500/20">
                Explore Projects
                <ArrowRight className="w-4 h-4" />
              </motion.button>
              <motion.button whileHover={{
              scale: 1.02
            }} whileTap={{
              scale: 0.98
            }} className="bg-white text-navy-900 border border-navy-100 px-8 py-4 rounded-md font-medium hover:border-navy-900 transition-colors">
                Our Services
              </motion.button>
            </motion.div>
          </div>

          {/* Image/Visual */}
          <motion.div initial={{
          opacity: 0,
          scale: 0.95
        }} animate={{
          opacity: 1,
          scale: 1
        }} transition={{
          duration: 0.8,
          delay: 0.2
        }} className="relative hidden lg:block">
            <div className="relative aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl">
              <img src="https://images.unsplash.com/photo-1512453979798-5ea904ac66de?q=80&w=2848&auto=format&fit=crop" alt="Dubai Skyline Architecture" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-900/60 to-transparent" />

              {/* Floating Card */}
              <motion.div initial={{
              opacity: 0,
              x: 20
            }} animate={{
              opacity: 1,
              x: 0
            }} transition={{
              duration: 0.6,
              delay: 0.6
            }} className="absolute bottom-8 right-8 bg-white/95 backdrop-blur-md p-6 rounded-xl shadow-xl max-w-xs border border-white/50">
                <div className="flex items-center gap-4 mb-3">
                  <div className="w-10 h-10 rounded-full bg-gold-100 flex items-center justify-center text-gold-600 font-bold">
                    15+
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 font-medium">
                      Years of Excellence
                    </p>
                    <p className="text-navy-900 font-bold">
                      Leading the Market
                    </p>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Decorative Frame */}
            <div className="absolute -z-10 top-8 -right-8 w-full h-full border-2 border-gold-500/30 rounded-2xl" />
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div initial={{
      opacity: 0
    }} animate={{
      opacity: 1
    }} transition={{
      delay: 1,
      duration: 1
    }} className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-navy-900/40">
        <span className="text-xs uppercase tracking-widest">Scroll</span>
        <motion.div animate={{
        y: [0, 5, 0]
      }} transition={{
        duration: 2,
        repeat: Infinity
      }}>
          <ChevronDown className="w-4 h-4" />
        </motion.div>
      </motion.div>
    </section>;
}