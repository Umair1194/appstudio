import React from 'react';
import { motion } from 'framer-motion';
import { Linkedin, Mail } from 'lucide-react';
const team = [{
  name: 'Ahmed Al-Mansoor',
  role: 'Chief Executive Officer',
  image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=2574&auto=format&fit=crop',
  bio: 'Visionary leader with 20 years of experience shaping the UAE real estate landscape.'
}, {
  name: 'Sarah Jenkins',
  role: 'Head of Design',
  image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=2576&auto=format&fit=crop',
  bio: 'Award-winning architect focused on sustainable luxury and modern aesthetics.'
}, {
  name: 'Mohammed Fayed',
  role: 'Director of Operations',
  image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=2670&auto=format&fit=crop',
  bio: 'Expert in operational excellence and strategic project execution across the region.'
}];
export function TeamSection() {
  return <section id="team" className="py-24 bg-off-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-navy-900 mb-4">
              Leadership Team
            </h2>
            <p className="text-gray-600 text-lg">
              Meet the visionaries behind Skyline Ventures.
            </p>
          </div>
          <button className="text-gold-600 font-medium hover:text-navy-900 transition-colors flex items-center gap-2 group">
            View All Members
            <span className="group-hover:translate-x-1 transition-transform">
              →
            </span>
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {team.map((member, index) => <motion.div key={index} initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6,
          delay: index * 0.2
        }} className="group relative h-[400px] w-full perspective-1000">
              <div className="relative w-full h-full transition-all duration-500 [transform-style:preserve-3d] group-hover:[transform:rotateY(180deg)]">
                {/* Front */}
                <div className="absolute inset-0 w-full h-full">
                  <div className="w-full h-full rounded-xl overflow-hidden shadow-lg relative">
                    <img src={member.image} alt={member.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                    <div className="absolute inset-0 bg-gradient-to-t from-navy-900/90 via-transparent to-transparent" />
                    <div className="absolute bottom-0 left-0 w-full p-6 text-white">
                      <h3 className="text-2xl font-serif font-bold mb-1">
                        {member.name}
                      </h3>
                      <p className="text-gold-400 text-sm font-medium uppercase tracking-wider">
                        {member.role}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Back */}
                <div className="absolute inset-0 w-full h-full [transform:rotateY(180deg)] [backface-visibility:hidden] rounded-xl overflow-hidden bg-navy-900 text-white p-8 flex flex-col justify-center items-center text-center shadow-xl border border-gold-500/20">
                  <div className="w-16 h-1 bg-gold-500 mb-6" />
                  <h3 className="text-2xl font-serif font-bold mb-2">
                    {member.name}
                  </h3>
                  <p className="text-gold-400 text-sm font-medium uppercase tracking-wider mb-6">
                    {member.role}
                  </p>
                  <p className="text-gray-300 leading-relaxed mb-8">
                    {member.bio}
                  </p>
                  <div className="flex gap-4">
                    <a href="#" className="p-2 rounded-full bg-white/10 hover:bg-gold-500 hover:text-navy-900 transition-colors">
                      <Linkedin className="w-5 h-5" />
                    </a>
                    <a href="#" className="p-2 rounded-full bg-white/10 hover:bg-gold-500 hover:text-navy-900 transition-colors">
                      <Mail className="w-5 h-5" />
                    </a>
                  </div>
                </div>
              </div>
            </motion.div>)}
        </div>
      </div>
    </section>;
}