import React from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';
const projects = [{
  title: 'The Royal Atlantis',
  location: 'Palm Jumeirah',
  image: 'https://images.unsplash.com/photo-1582672060674-bc2bd808a8b5?q=80&w=2835&auto=format&fit=crop',
  size: 'large'
}, {
  title: 'Marina Heights',
  location: 'Dubai Marina',
  image: 'https://images.unsplash.com/photo-1518684079-3c830dcef090?q=80&w=2787&auto=format&fit=crop',
  size: 'small'
}, {
  title: 'Downtown Views',
  location: 'Downtown Dubai',
  image: 'https://images.unsplash.com/photo-1546412414-e1885259563a?q=80&w=2787&auto=format&fit=crop',
  size: 'small'
}, {
  title: 'Creek Harbour',
  location: 'Dubai Creek',
  image: 'https://images.unsplash.com/photo-1578321272176-b7bbc0679853?q=80&w=2835&auto=format&fit=crop',
  size: 'wide'
}];
export function ExploreSection() {
  return <section id="explore" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-gold-600 font-medium uppercase tracking-widest text-sm">
            Portfolio
          </span>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-navy-900 mt-3 mb-6">
            Featured Projects
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 auto-rows-[300px]">
          {projects.map((project, index) => <motion.div key={index} initial={{
          opacity: 0,
          scale: 0.95
        }} whileInView={{
          opacity: 1,
          scale: 1
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6,
          delay: index * 0.1
        }} className={`group relative rounded-xl overflow-hidden cursor-pointer ${project.size === 'large' ? 'md:col-span-2 md:row-span-2' : project.size === 'wide' ? 'md:col-span-3' : ''}`}>
              <img src={project.image} alt={project.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />

              {/* Overlay */}
              <div className="absolute inset-0 bg-navy-900/20 group-hover:bg-navy-900/60 transition-colors duration-500" />

              {/* Content */}
              <div className="absolute inset-0 p-8 flex flex-col justify-end opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                  <p className="text-gold-400 text-sm font-medium uppercase tracking-wider mb-2">
                    {project.location}
                  </p>
                  <div className="flex items-center justify-between">
                    <h3 className="text-3xl font-serif font-bold text-white">
                      {project.title}
                    </h3>
                    <div className="w-12 h-12 rounded-full bg-gold-500 flex items-center justify-center text-white">
                      <ArrowUpRight className="w-6 h-6" />
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>)}
        </div>

        <div className="mt-12 text-center">
          <button className="inline-flex items-center gap-2 text-navy-900 font-medium border-b-2 border-gold-500 pb-1 hover:text-gold-600 transition-colors">
            View All Projects <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>;
}