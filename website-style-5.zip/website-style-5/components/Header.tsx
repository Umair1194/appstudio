import React, { useEffect, useState } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';
export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const {
    scrollY
  } = useScroll();
  const headerBackground = useTransform(scrollY, [0, 50], ['rgba(255, 255, 255, 0)', 'rgba(255, 255, 255, 0.95)']);
  const headerShadow = useTransform(scrollY, [0, 50], ['none', '0 4px 6px -1px rgba(0, 0, 0, 0.05)']);
  const headerBackdrop = useTransform(scrollY, [0, 50], ['blur(0px)', 'blur(12px)']);
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  const navLinks = [{
    name: 'Services',
    href: '#services'
  }, {
    name: 'About',
    href: '#stats'
  }, {
    name: 'Portfolio',
    href: '#explore'
  }, {
    name: 'Team',
    href: '#team'
  }];
  return <motion.header style={{
    backgroundColor: headerBackground,
    boxShadow: headerShadow,
    backdropFilter: headerBackdrop
  }} className="fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b border-transparent data-[scrolled=true]:border-gold-500/10" data-scrolled={isScrolled}>
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 md:h-24 transition-all duration-300">
          {/* Logo */}
          <motion.a href="#" className="flex items-center gap-2 group" whileHover={{
          scale: 1.02
        }}>
            <div className="w-10 h-10 bg-navy-900 rounded-tr-xl rounded-bl-xl flex items-center justify-center border border-gold-500/30 group-hover:border-gold-500 transition-colors">
              <span className="text-gold-500 font-serif font-bold text-xl">
                S
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-navy-900 font-serif font-bold text-xl leading-none tracking-tight">
                SKYLINE
              </span>
              <span className="text-gold-600 text-[0.65rem] uppercase tracking-[0.2em] font-medium">
                Ventures
              </span>
            </div>
          </motion.a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map(link => <a key={link.name} href={link.href} className="text-sm font-medium text-navy-800 hover:text-gold-600 transition-colors relative group py-2">
                {link.name}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gold-500 transition-all duration-300 group-hover:w-full" />
              </a>)}
            <motion.button whileHover={{
            scale: 1.05
          }} whileTap={{
            scale: 0.95
          }} className="bg-navy-900 text-white px-6 py-2.5 rounded-md font-medium text-sm border border-navy-900 hover:bg-transparent hover:text-navy-900 hover:border-navy-900 transition-all duration-300">
              Contact Us
            </motion.button>
          </nav>

          {/* Mobile Menu Button */}
          <button className="md:hidden text-navy-900" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && <motion.div initial={{
        opacity: 0,
        height: 0
      }} animate={{
        opacity: 1,
        height: 'auto'
      }} exit={{
        opacity: 0,
        height: 0
      }} className="md:hidden bg-white border-t border-gray-100 overflow-hidden">
            <div className="px-6 py-8 space-y-4">
              {navLinks.map(link => <a key={link.name} href={link.href} onClick={() => setIsMobileMenuOpen(false)} className="block text-lg font-serif font-medium text-navy-900 hover:text-gold-600">
                  {link.name}
                </a>)}
              <button className="w-full mt-4 bg-gold-500 text-white px-6 py-3 rounded-md font-medium hover:bg-gold-600 transition-colors">
                Contact Us
              </button>
            </div>
          </motion.div>}
      </AnimatePresence>
    </motion.header>;
}